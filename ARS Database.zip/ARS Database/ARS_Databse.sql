
--/*********************************************************************
-- * File                 : ARS_Database.sql
-- * Author Name          : Group 1
-- * Desc                 : Development of an online Airline Reservation System(ARS) 
-- * Version              : 1.0
-- * Last Modified Date   : 04-Jan-2019
-- * Change Description   : Description about the changes implemented
-- *********************************************************************/

  --Schema Creation

  create schema airline;

 --Flight Table Creation


 create table [airline].[Flights]
(
 FlightID varchar(10) primary key, 
 LaunchDate date, 
 Origin varchar(10), 
 Destination varchar(10), 
 DeptTime varchar(10), 
 ArrivalTime varchar(10),
 NoOfSeats int, 
 Fare decimal
 );

 --Reservation Table Creation

 Create table [airline].[Reservation]
 (
  --TicketNo int identity primary key, 
   TicketNumber INT IDENTITY(1,40) NOT NULL PRIMARY KEY CLUSTERED,
   TicketNo AS 'CG' + RIGHT('000000' + CAST(TicketNumber AS VARCHAR(8)), 8) PERSISTED,
  FlightID varchar(10), 
  DateofBooking date, 
  JourneyDate date, 
  PassengerName varchar(50),
  Age int,
  Gender varchar(10),
  ContacNo bigint,
  Email varchar(70),
  Class varchar(20),
  NoofTickets int, 
  TotalFare decimal,
  ReservationStatus varchar(20), --Staus will have either of the following values Booked or Cancelled
  constraint CHK_Gender check(Gender IN ('Male','Female')),
  constraint CHK_Class check(Class IN ('First Class','Business Class','Economy Class')),
  constraint CHK_Status check(ReservationStatus IN ('Booked','Cancelled')),
  constraint FK_FlightID foreign key(FlightID) 
  references airline.Flights(FlightID)
);

--Admin(user) Table Reservation

Create table airline.Users
(
 Id int identity primary key, 
 Username varchar(30),
 UserPassword varchar(30)
);


--FlightClass table creation 

 Create table airline.FlightClass(
 FlightID varchar(10),
 Class varchar(20),
 Fare decimal,
 CONSTRAINT FK_FlightClass FOREIGN KEY (FlightID)
 REFERENCES airline.Flights(FlightID)
 );

--Inserting Data into FlightClass Table

	Insert into airline.FlightClass values(109,'Business Class',15000)
	Insert into airline.FlightClass values(109,'First Class',10000)
	Insert into airline.FlightClass values(109,'Economy Class',15000)

	Insert into airline.FlightClass values(110,'Business Class',15000)
	Insert into airline.FlightClass values(110,'First Class',10000)
	Insert into airline.FlightClass values(110,'Economy Class',15000)

	Insert into airline.FlightClass values(101,'Business Class',15000)
	Insert into airline.FlightClass values(101,'First Class',10000)
	Insert into airline.FlightClass values(101,'Economy Class',15000)


--Inserting Data into Flight Table Table

 INSERT INTO [airline].[Flights] VALUES 
( '102', '2018-12-21', 'Pune' , 'Patna', ' 8:00 AM ' , ' 12:00 PM ' , 145 ,  10000 ),
( '104', '2018-09-11', 'Mumbai' , 'New Delhi', ' 09:00 PM ' , ' 11:00 PM ' , 100 ,  8000 ),
( '110', '2019-08-19', 'Patna' , 'Bangalore', ' 6:00 AM ' , ' 10:00 AM ' , 110 ,  12000 );


--Inserting Data into Reservation Table

insert into airline.Reservation values('109','08/18/2017','10/14/2017', 'Johny Boosh', 30, 'Male', 8569325478,'johny@gmail.com','Business Class',1,10000,'Booked')

insert into airline.Reservation values('101','05/18/2017','06/14/2017', 'John Mellen', 40, 'Male', 8569325478,'john@gmail.com','Economy Class',1,5000,'Booked')

--Inserting Data into Users Table

 INSERT INTO [airline].[Users] VALUES 
( 'alam123' , '1234567' ),
( 'ratnesh768' , 'rat5643' ),
( 'raju9768' , 'ra123ju' );

-- Showing All the Details

select * from airline.Flights
select * from airline.Reservation
select * from airline.Users
select * from airline.FlightClass


--List Of all The Procedures Used


--Creating procedure to insert data into Flights table

CREATE PROC [airline].[USP_FLIGHTINSERT]
(
 @flightId varchar(10) ,
 @launchDate date,
 @origin varchar(10),
 @destination varchar(10),
 @deptTime  varchar(10),
 @arrivalTime varchar(10),
 @noOfSeats int)

 As

 BEGIN
		INSERT INTO [airline].[Flights]
							(FlightID, 
							LaunchDate, 
							Origin, 
							Destination, 
							DeptTime, 
							ArrivalTime,
							NoOfSeats 
							) 

			       VALUES (@flightId,
							@launchDate,
							@origin,
							@destination,
							@deptTime,
							@arrivalTime,
							@noOfSeats
							);

END


--Creating procedure to delete data from Flights table

CREATE PROC [airline].[USP_FLIGHTDELETE]
    
@flightId varchar(10) 

As

BEGIN

		DELETE FROM [airline].[Flights] WHERE FlightID = @flightId;

END

--Creating procedure to view flight details from Flights table
	
CREATE PROC [airline].[USP_VIEWFLIGHTS]
    
@origin varchar(20),
@destination varchar(20)

As

BEGIN

		SELECT FlightID, Origin,Destination, DeptTime, ArrivalTime,NoOfSeats FROM [airline].[Flights] WHERE Origin = @origin AND Destination = @destination;

END

--Creating procedure to view reservation details from Reservation table

CREATE PROC [airline].[USP_VIEWRESERVATION]
    
@ticketNo int

As

BEGIN

		SELECT * FROM [airline].[Reservation] WHERE TicketNo = @ticketNo

END

--Creating procedure to generate total revenue from Reservation table

CREATE PROC [airline].[USP_Rev]

 @f_ID int

AS

BEGIN

SELECT  Sum(NoofTickets*TotalFare) AS "Total Revenue" FROM [airline].[Reservation]  WHERE Class IN('Business Class','Economy Class','First Class') AND FlightID = @f_ID ;

END


--Creating procedure to calculate total revenue from Reservation table

CREATE PROC [airline].[USP_Rev123]

AS

BEGIN

SELECT Sum(TotalFare) AS "Total Revenue" FROM [airline].[Reservation];

END

--Creating procedure to insert data into Reservation table

CREATE PROC [airline].[USP_RESERVATIONINSERT]
(
  @flightID varchar(10), 
  @dateofBooking date, 
  @journeyDate date, 
  @passengerName varchar(50),
  @age int,
  @gender varchar(10),
  @contacNo bigint,
  @email varchar(70),
  @class varchar(20),
  @noofTickets int, 
  @totalFare decimal,
  @reservationStatus varchar(20))

 As

 BEGIN
		INSERT INTO [airline].Reservation
							( FlightID, 
							  DateofBooking, 
							  JourneyDate, 
							  PassengerName,
							  Age,
							  Gender,
							  ContacNo,
							  Email,
							  Class,
							  NoofTickets, 
							  TotalFare,
							  ReservationStatus) 

			       VALUES (   @flightID, 
							  @dateofBooking, 
							  @journeyDate, 
							  @passengerName,
							  @age,
							  @gender,
							  @contacNo,
							  @email,
							  @class,
							  @noofTickets, 
							  @totalFare,
							  @reservationStatus);
END



--Creating procedure to search a user 

 CREATE PROC [airline].[USP_USERSEARCH]
    
 @userName varchar(20),
 @password varchar(20)

 As

 BEGIN
		SELECT COUNT(*) FROM [airline].[Users] WHERE Username = @userName AND UserPassword= @password;
 END


 --Creating procedure for class booking

 create proc [airline].[USP_CLASSBOOKING]  
( @flightID varchar(10),  
@flightClass varchar(20), 
@journeyDate date,
@noOfPassengers int
)  
  
 As  

 declare @classcnt int  
 declare @tickets int  
 declare @seats int  
  
 BEGIN  

 Set @tickets = 0
 Set @seats = 0

  select  @tickets=  sum(noOfTickets) from airline.reservation where FlightID=@flightID and Class = @flightClass and ReservationStatus = 'Booked' and JourneyDate = @journeyDate
select @seats = TotalSeats from airline.FlightClass where FlightID=@flightID and Class = @flightClass  
  
if(@tickets >= @seats )  
begin  
return 0  
end  
else if ((@seats - @tickets) < @noOfPassengers)
begin  
return 0  
end  
else 
begin  
return 1
end  

 
  
 END


 --Creating procedure to cancel ticket


create proc [airline].[USP_CancelTicket]

@ticketNo varchar(12)

AS

BEGIN

if(JourneyDate>getdate())

begin

update airline.reservation set ReservationStatus='cancelled' where TicketNo = @ticketNo;

end

else if(JourneyDate<getdate())

begin

update airline.reservation set ReservationStatus='cancelled', TotalFare=TotalFare-0.6*TotalFare where TicketNo = @ticketNo;

end

 

END 

-- Select query to fetch fare from Flight table

Select fare from airline.FlightClass where FlightId=@flightId and Class=@flightClass;

-- Select query to get Ticket number 

Select max(TicketNo) from airline.reservation

-- Select query to fetch fare of respective class from flight table

Select fare from airline.FlightClass where Class=@flightClass

-- Inserting flight ticket class into flight class table

insert into airline.FlightClass values (@flightId,'First Class',@fClassFare,@fClassSeats),(@flightId,'Economy Class',@eClassFare,@eClassSeats