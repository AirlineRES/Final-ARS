﻿//<Summary>
/*********************************************************************
 * File                 : FlightDAL.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 15-Dec-2019
 *********************************************************************/
//</Summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace AirlineReservationSystemDAL
{
    public class FlightDAL
    {
        //Declaring SqlConnection object reference
        SqlConnection con = null;

        //Declaring SqlCommand object reference
        SqlCommand cmd = null;

        //Declaring Data Reader object reference
        SqlDataReader dr = null;
        
        public FlightDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        }

        //DAL Method to insert data in Flights table using Stored Procedure 

        public bool InsertFlightDAL(Flight flight)
        {
            bool isInserted = false;
            try
            {
                cmd = new SqlCommand("Airline.USP_FLIGHTINSERT", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flightId", flight.FlightID);
                cmd.Parameters.AddWithValue("@launchDate", flight.LaunchDate);
                cmd.Parameters.AddWithValue("@origin", flight.Origin);
                cmd.Parameters.AddWithValue("@destination", flight.Destination);
                cmd.Parameters.AddWithValue("@deptTime", flight.DeptTime);
                cmd.Parameters.AddWithValue("@arrivalTime", flight.ArrivalTime);
                cmd.Parameters.AddWithValue("@noOfSeats", flight.NoOfSeats);
               
                con.Open();
                cmd.ExecuteNonQuery();
                isInserted = true;
            }

            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return isInserted;
        }

        //DAL Method to delete data in Flights table using Stored Procedure 

        public bool DeleteFlightDAL(int id)
        {
            bool isDeleted = false;
            try
            {
                cmd = new SqlCommand("[Airline].[USP_FLIGHTDELETE]", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flightId", id);
                con.Open();
                if (cmd.ExecuteNonQuery() > 0)
                    isDeleted = true;
              
            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }

            return isDeleted;
        }
        
        //DAL Method to Select and populate data from Flights table

        public IEnumerable<Flight> ViewFlightsDAL(string origin,string destination)
        {
            List<Flight> flights = new List<Flight>();
            try
            {
                cmd = new SqlCommand("Airline.USP_VIEWFLIGHTS", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@origin", origin);
                cmd.Parameters.AddWithValue("@destination", destination);
                con.Open();
                
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Flight flight = new Flight();
                        flight.FlightID = Convert.ToInt32(dr[0]);
                        flight.Origin = dr[1].ToString();
                        flight.Destination = dr[2].ToString();
                        flight.DeptTime =dr[3].ToString();
                        flight.ArrivalTime = dr[4].ToString();
                        flight.NoOfSeats =Convert.ToInt32(dr[5]);
                        flights.Add(flight);
                    }
                }
                dr.Close();

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return flights;
        }
                
        //DAL Method to Select ticket from reservation table

        public Reservation ViewTicketDAL(string ticketNo)
        {
            Reservation ticket = new Reservation();
            try
            {
                cmd = new SqlCommand("airline.USP_VIEWRESERVATION", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ticketNo", ticketNo);
                con.Open();
                
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                                         
                        ticket.TicketNo = dr[1].ToString();
                        ticket.FlightId = dr[2].ToString();
                        ticket.DateofBooking= dr[3].ToString();
                        ticket.JourneyDate = dr[4].ToString();
                        ticket.PassengerName = dr[5].ToString();
                        ticket.Age = Convert.ToInt32(dr[6]);
                        ticket.Gender = dr[7].ToString();
                        ticket.ContactNo = dr[8].ToString();
                        ticket.Email = dr[9].ToString();
                        ticket.Class = dr[10].ToString();
                        ticket.NoofTickets = Convert.ToInt32(dr[11]);
                        ticket.TotalFare = Convert.ToDecimal(dr[12]);
                        ticket.Status = dr[13].ToString();
                    }
                }
                dr.Close();

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return ticket;
        }

        //DAL Method to get fare from FlightClass  

        public decimal getFare(string flightClass)
        {
            cmd = new SqlCommand("Select fare from airline.FlightClass where Class=@flightClass", con);
            cmd.Parameters.AddWithValue("@flightClass", flightClass);
            con.Open();
            decimal fare =  Convert.ToDecimal( cmd.ExecuteScalar());
            con.Close();
            return fare;
          //  Console.WriteLine(fare);
        }

        //DAL method to get TicketNo from Reservation table
        public string getTicketNo()
        {
            

            cmd = new SqlCommand("Select max(TicketNo) from airline.reservation", con);
            con.Open();
            string ticketNo = cmd.ExecuteScalar().ToString();
            con.Close();
            return ticketNo;
        }

        // DAL Method to generate total revenue for particular flight

        public FlightRevenue TotalRevenueDAL(int FlightID)
        {
            FlightRevenue rev = new FlightRevenue();

            try
            {
                rev.flightID = FlightID;
                cmd = new SqlCommand("[airline].[USP_Rev]", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@f_Id", FlightID);

                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        rev.TotalRevenue = Convert.ToInt32(dr[0]);
                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return rev;
        }

        // DAL Method to generate total revenue for all flights
        public IEnumerable<RevenueOverall> TotalRevenueSpecifiedDAL()
        {
            List<RevenueOverall> revList = new List<RevenueOverall>();
            try
            {
                cmd = new SqlCommand("[Airline].[USP_Rev123]", con);

                con.Open();

                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        RevenueOverall reven = new RevenueOverall();


                        reven.TotalSpecified = Convert.ToInt32(dr[0]);
                        //reven.Date2 = Convert.ToDateTime(dr[1]);
                        revList.Add(reven);

                    }
                }
                dr.Close();

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return revList;
        }

        //DAL method to insert flight class
        public bool InsertFlightClassDAL(int flightId,int fClassSeats,decimal fClassFare, int EClassSeats, decimal EClassFare ,int BClassSeats, decimal BClassFare)
        {
            bool isInserted = false;
            try
            {
                cmd = new SqlCommand("insert into airline.FlightClass values (@flightId,'First Class',@fClassFare,@fClassSeats),(@flightId,'Economy Class',@eClassFare,@eClassSeats),(@flightId,'Business Class',@bClassFare,@bClassSeats)", con);
                cmd.Parameters.AddWithValue("@flightId", flightId);
                cmd.Parameters.AddWithValue("@fClassSeats", fClassSeats);
                cmd.Parameters.AddWithValue("@fClassFare", fClassFare);
                cmd.Parameters.AddWithValue("@eClassSeats", EClassSeats);
                cmd.Parameters.AddWithValue("@eClassFare", EClassFare);
                cmd.Parameters.AddWithValue("@bClassSeats", BClassSeats);
                cmd.Parameters.AddWithValue("@bClassFare", BClassFare);
                //cmd.Parameters.AddWithValue("@fare", flight.Fare);

                con.Open();
                cmd.ExecuteNonQuery();
                isInserted = true;
            }

            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return isInserted;
        }

        // DAL Method to get flight classes for particular flight
        public IEnumerable<FlightFare> GetFlightClass(int flightId)
        {
            List<FlightFare> flightFareList = new List<FlightFare>();
            try
            {
                cmd = new SqlCommand("Select * from Airline.FlightClass where FlightId = @flightId", con);
              
                cmd.Parameters.AddWithValue("@flightId", flightId);
                
                con.Open();

                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        FlightFare flightFare = new FlightFare();
                        flightFare.FlightId = Convert.ToInt32(dr[0]);
                        flightFare.FlightClass = dr[1].ToString();
                        flightFare.Fare = Convert.ToInt32(dr[2]);
                        flightFare.seats = Convert.ToInt32(dr[3]);
                        flightFareList.Add(flightFare);
                    }
                }
                dr.Close();

            }
            catch (AirlineException ae)
            {
                throw ae;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return flightFareList;
        }




    }
}
