﻿//<Summary>
/*********************************************************************
 * File                 : Reservation.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 10-Dec-2019
 *********************************************************************/
//</Summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirlineReservationSystemEntities;

namespace AirlineReservationSystemEntities
{
    // Class to create the properties of Reservation class

    public class Reservation
    {
        public string TicketNo { get; set; }
        public string FlightId { get; set;}
        public string DateofBooking{ get; set; }
        public string JourneyDate { get; set; }
        public string PassengerName { get; set; }
        public string ContactNo { get; set; }
        public string Email { get; set; }
        public int NoofTickets{ get; set; }
        public decimal TotalFare { get; set; }
        public string Status{ get; set; }
        public int Age { get; set; }
        public string Class { get; set; }
        public string Gender { get; set; }
    }
}
