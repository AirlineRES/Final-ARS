﻿//<Summary>
/*********************************************************************
 * File                 : RevenueOverall.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 10-Dec-2019
 *********************************************************************/
//</Summary>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlineReservationSystemEntities
{
    // Class to create the properties of RevenueOverall class
    public class RevenueOverall
    {
        private int _totalSpecified;
        public int TotalSpecified
        {
            get
            {
                return _totalSpecified;
            }
            set

            {
                _totalSpecified = value;
            }
        }
    }
}
