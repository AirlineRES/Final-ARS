﻿//<Summary>
/*********************************************************************
 * File                 : BookTicket.xaml.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 29-Dec-2019
 *********************************************************************/
//</Summary>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;


namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for BookTicket.xaml
    /// </summary>
    public partial class BookTicket : Window
    {
        public BookTicket()
        {
            InitializeComponent();
        }

        //validation for user input
        public bool Validation()
        {
            StringBuilder sb = new StringBuilder();
            bool isValid = true;

            if (txtBookName.Text.Length == 0)
            {
                sb.Append("Please Enter Name...!!!");
                isValid = false;
            }

            if (txtBookContact.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Contact...!!!");
                isValid = false;
            }

            if (txtBookemail.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Email...!!!");
                isValid = false;
            }

            if (!(rbBookMale.IsChecked == true || rbBookFemale.IsChecked == true))
            {
                sb.Append("\nPlease Enter Gender...!!!");
                isValid = false;
            }

            if (txtBookPassengers.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Number of Passengers...!!!");
                isValid = false;
            }

            if (txtAge.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Age...!!!");
                isValid = false;
            }
       
            if (!isValid)
            {
                //throw new Exception(sb.ToString());
                MessageBox.Show(sb.ToString());
            }

            return isValid;
        }

        //button click event for book ticket
        private void BtnBook_Click(object sender, RoutedEventArgs e)
        {
            if (Validation())
            {
                BookTicketPL();
            }
        }

        
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayClass();
        }

        //method for display class
        public void DisplayClass()
        {
            try
            {

                IEnumerable<FlightFare> flightFares = FlightBL.GetFlightClass(Convert.ToInt32(txtFlightID.Text));
                cbClass.ItemsSource = flightFares;
                cbClass.DisplayMemberPath = "FlightClass";               
             
            }
            catch (AirlineException ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        //method for book ticket
        public void BookTicketPL()
        {
            try
            {
                
                Reservation ticket = new Reservation();

                ticket.FlightId = txtFlightID.Text;
                ticket.DateofBooking = DateTime.Now.Date.ToString();
                ticket.JourneyDate = dpJourneyDate.Text;// Journery Date not Specified
                ticket.PassengerName = txtBookName.Text;
                ticket.ContactNo = txtBookContact.Text;
                ticket.Email = txtBookemail.Text;
                ticket.NoofTickets = Convert.ToInt32(txtBookPassengers.Text);
                ticket.Age = Convert.ToInt32(txtAge.Text); // Age no specified
                //ComboBoxItem cmb = (ComboBoxItem)cbClass.SelectedItem;
                FlightFare flightFare = (FlightFare)cbClass.SelectedItem;
                ticket.Class = flightFare.FlightClass;

                if (rbBookMale.IsChecked == true)
                    ticket.Gender = rbBookMale.Content.ToString();
                else
                    ticket.Gender = rbBookFemale.Content.ToString();



                string ticketNo = TicketBL.BookTicketBL(ticket);
                if (ticketNo != "NA")
                {
                    MessageBox.Show("Welcome "+ ticket.PassengerName +"\n\n Your Ticket No. : " + ticketNo +"\n Journey Date : "
                        + ticket.JourneyDate + "\n Ticket Class : " + ticket.Class + "\n No of Ticket : " + ticket.NoofTickets + "\n Total Fare is : Rs " + ticket.NoofTickets * Convert.ToInt32(txtFare.Text));

                    //txtFlightID.Text = string.Empty;
                    txtBookName.Text = string.Empty;
                    txtBookPassengers.Text = string.Empty;
                    txtBookContact.Text = string.Empty;
                    txtBookemail.Text = string.Empty;
                    txtFare.Text = string.Empty;
                    txtAge.Text = string.Empty;

                    dpJourneyDate.SelectedDate = DateTime.Now.Date;

                }
                else
                    MessageBox.Show("No seats Or Less Seats Available");

            }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //hyper link event for home window
        private void Hyperlink_Home(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            HomePage homePage = new HomePage();
            homePage.Show();
            this.Close();
        }
    }
}
