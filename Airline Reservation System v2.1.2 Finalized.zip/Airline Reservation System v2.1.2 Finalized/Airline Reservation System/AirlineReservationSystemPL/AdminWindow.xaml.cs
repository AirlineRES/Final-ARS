﻿//<Summary>
/*********************************************************************
 * File                 : AdminWindow.xaml.cs
 * Author Name          : Group 1
 * Desc                 : Development of an online Airline Reservation 
 *                        System (ARS)
 * Version              : 1.0
 * Last Modified Date   : 29-Dec-2019
 *********************************************************************/
//</Summary>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;
using AirlineReservationSystemDAL;

namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for AdminWindow.xaml
    /// </summary>
    public partial class AdminWindow : Window
    {
        public AdminWindow()
        {
            InitializeComponent();
        }

        //window event for add flight
        private void AddFlight_Click(object sender, RoutedEventArgs e)
        {
            AddFlight addFlight = new AddFlight();
            addFlight.Show();
            this.Close();
        }

        //button click event for generate overall revenue 
        private void BtnGenRevOver_Click(object sender, RoutedEventArgs e)
        {

            try
            {

                RevenueOverall rev = new RevenueOverall();
                FlightDAL revenueDAL = new FlightDAL();

                IEnumerable<RevenueOverall> revList =
                revenueDAL.TotalRevenueSpecifiedDAL();
                dgOverallRev.Visibility = Visibility.Visible;
                dgOverallRev.ItemsSource = revList;
            }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch(Exception)
            {
                MessageBox.Show("No bookings for this flight ID");
            }

        }

        //button click event for generate flight revenue
        private void BtnGenRev_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                FlightRevenue rev = new FlightRevenue();

                int id = Convert.ToInt32(txtGenID.Text);
                rev = FlightBL.TotalRevenueBL(id);
                IEnumerable<FlightRevenue> reven = new List<FlightRevenue> { rev };
                gvFlightrev.Visibility = Visibility.Visible;
                if (dgOverallRev.IsVisible)
                    dgOverallRev.Visibility = Visibility.Hidden;
                dgFlighRev.Visibility = Visibility.Visible;
                dgFlighRev.ItemsSource = reven;

                txtGenID.Text = string.Empty;

            }
            catch (AirlineException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception)
            {
                txtGenID.Text = string.Empty;
                MessageBox.Show("No bookings for this flight ID");
            }
        }

        //button click event for remove flight
        private void BtnRemFlight_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                if (dgFlighRev.IsVisible || dgOverallRev.IsVisible)
                {
                    dgOverallRev.Visibility = Visibility.Hidden;
                    dgFlighRev.Visibility = Visibility.Hidden;
                }

                bool flightRemoved = false;
                if(txtRemID.Text!=null)
                   flightRemoved = FlightBL.DeleteFlightBL(Convert.ToInt32(txtRemID.Text));
                if (flightRemoved)
                    MessageBox.Show("Flight removed Successfully");
                else
                    MessageBox.Show("Flight ID is not found");
                txtRemID.Text = string.Empty;

            }
            catch (AirlineException ex)
            {
                MessageBox.Show(ex.Message);
            }
            

        }


        //hyperlink event for home window
        private void Hyperlink_Logout(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            HomePage homePage = new HomePage();
            homePage.Show();
            this.Close();
        }
    }
}
