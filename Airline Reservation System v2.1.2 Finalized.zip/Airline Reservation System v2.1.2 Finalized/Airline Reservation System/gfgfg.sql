﻿select * from airline.reservation
select * from airline.flights
select * from airline.FlightClass
Select * from airline.FlightClass where Class='First Class'
exec sp_help 'airline.USP_RESERVATIONINSERT'
exec sp_help 'airline.reservation'

 EXEC [airline].[USP_RESERVATIONINSERT] 109,'05/20/2017','06/24/2017', 'Bill Gates', 40, 'Male', 8569325478,'bill@hotmail.com','First Class',1,15000,'Booked'
 Select fare from airline.FlightClass where Class='First Class' and FlightId='101'

 
( @flightID varchar(10),
@flightClass varchar(20)
)

 As
 declare @classcnt int
 declare @tickets int
 declare @seats int

 BEGIN
  select  @tickets=  sum(noOfTickets) from airline.reservation where FlightID=@flightID and Class = @flightClass and ReservationStatus = 'Booked'
select @seats = TotalSeats from airline.FlightClass where FlightID=@flightID and Class = @flightClass

if(@tickets < @seats )
begin
return 1
end
else
begin
return 0
end

	END

	declare @abc int;
	Exec @abc = [airline].[USP_CLASSBOOKING] '103', 'First Class';
	print @abc
 
 
