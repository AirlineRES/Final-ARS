﻿select * from airline.flights
select * from airline.reservation;

update airline.reservation set ReservationStatus='Booked' where TicketNo='CG00001321';

exec sp_helptext '[Airline].[USP_FLIGHTINSERT]'
exec sp_helptext '[Airline].[USP_FLIGHTDelete]'
exec sp_helptext '[Airline].[USP_VIEWRESERVATION]'
exec sp_helptext '[airline].[reservation]'

select * from airline.FlightClass
delete from airline.FlightClass where FlightID=110;
delete from airline.Reservation where FlightID = 110;
delete from airline.flights where FlightID = 110;
select * from airline.Reservation where TicketNo = 'CG00000121';

exec [airline].[USP_VIEWFLIGHTS] 'goa' , 'mumbai'
exec [Airline].[USP_FLIGHTINSERT] 2 ,'12-12-2018', 'goa' , 'mumbai', '4:45', '5:45', 50

exec [Airline].[USP_VIEWRESERVATION] 'CG00000121'

drop proc [airline].[USP_VIEWRESERVATION]


CREATE PROC [airline].[USP_VIEWRESERVATION]
    
     @ticketNo varchar(12)

     As

     BEGIN
		SELECT * FROM [airline].[Reservation] WHERE TicketNo = @ticketNo
      END

EXEC [airline].[USP_VIEWRESERVATION] 3
	   select * from [airline].Reservation 

